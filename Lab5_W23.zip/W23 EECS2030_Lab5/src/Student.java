import java.util.Date;

public class Student extends Person {
}
